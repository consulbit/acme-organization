---
date: {{ .Date }}
title: "{{ replace .Name "-" " " | title }}"
description: "Placeholder"
draft: true
---
